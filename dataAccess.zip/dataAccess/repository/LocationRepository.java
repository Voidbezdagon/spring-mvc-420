package com.cm.repository;

import org.springframework.stereotype.Repository;

import com.cm.entity.Location;

@Repository
public class LocationRepository extends BaseRepository<Location>{
	


}
