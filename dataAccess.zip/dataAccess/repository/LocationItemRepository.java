package com.cm.repository;

import org.springframework.stereotype.Repository;

import com.cm.entity.LocationItem;

@Repository
public class LocationItemRepository extends BaseRepository<LocationItem>{
	
	
	
}
