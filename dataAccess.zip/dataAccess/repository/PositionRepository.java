package com.cm.repository;

import org.springframework.stereotype.Repository;

import com.cm.entity.Position;

@Repository
public class PositionRepository extends BaseRepository<Position>{

}
