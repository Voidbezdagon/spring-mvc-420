package com.cm.repository;

import org.springframework.stereotype.Repository;

import com.cm.entity.ScheduleActivityReport;

@Repository
public class ScheduleActivityReportRepository extends BaseRepository<ScheduleActivityReport> {

}
