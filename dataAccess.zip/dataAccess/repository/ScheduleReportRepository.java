package com.cm.repository;

import org.springframework.stereotype.Repository;

import com.cm.entity.ScheduleReport;

@Repository
public class ScheduleReportRepository extends BaseRepository<ScheduleReport>{

}
