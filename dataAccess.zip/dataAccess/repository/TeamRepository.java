package com.cm.repository;

import org.springframework.stereotype.Repository;

import com.cm.entity.Team;

@Repository
public class TeamRepository extends BaseRepository<Team>{

}
