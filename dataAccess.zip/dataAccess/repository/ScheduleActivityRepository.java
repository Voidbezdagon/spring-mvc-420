package com.cm.repository;

import org.springframework.stereotype.Repository;

import com.cm.entity.ScheduleActivity;

@Repository
public class ScheduleActivityRepository extends BaseRepository<ScheduleActivity> {

}
