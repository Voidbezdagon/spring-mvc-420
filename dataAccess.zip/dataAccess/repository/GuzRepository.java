package com.cm.repository;

import org.springframework.stereotype.Repository;

import com.cm.entity.Guz;

@Repository
public class GuzRepository extends BaseRepository<Guz>{
	
}
