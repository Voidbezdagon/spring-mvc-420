package com.cm.service;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cm.entity.Guz;

@Service
@Transactional
public class GuzService extends BaseService<Guz>{

}
