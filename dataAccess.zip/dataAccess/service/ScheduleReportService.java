package com.cm.service;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cm.entity.ScheduleReport;

@Service
@Transactional
public class ScheduleReportService extends BaseService<ScheduleReport>{

}