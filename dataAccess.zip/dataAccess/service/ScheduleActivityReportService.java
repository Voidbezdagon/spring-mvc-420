package com.cm.service;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cm.entity.ScheduleActivityReport;

@Service
@Transactional
public class ScheduleActivityReportService extends BaseService<ScheduleActivityReport> {

}
