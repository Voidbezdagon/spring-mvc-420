package com.cm.service;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cm.entity.ScheduleActivity;

@Service
@Transactional
public class ScheduleActivityService extends BaseService<ScheduleActivity> {

}
